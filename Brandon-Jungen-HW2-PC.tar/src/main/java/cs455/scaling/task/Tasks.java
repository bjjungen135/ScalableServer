package cs455.scaling.task;

public interface Tasks {

	public void execute();
}
